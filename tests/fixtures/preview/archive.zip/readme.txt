Unsupported preview fallback fixture.
